DEBUG = False
FLATPAGES_ROOT = 'blog/pages'
FLATPAGES_EXTENSION = '.md'


AUTHOR = u'Mao quan'
SITEURL = ' http://182.254.131.130/blog'

DEFAULT_LANG = u'en'


GITHUB = 'http://github.com/wwmmqq'
MAIL_ADDR = 'myqway@outloo.com'
